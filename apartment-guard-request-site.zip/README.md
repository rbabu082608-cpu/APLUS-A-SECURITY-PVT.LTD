
# APLUS A SECURITY – Apartment Guard Request Site

A lightweight, mobile-friendly site for apartment tenants/RWAs to contact APLUS A SECURITY and estimate guard wages **including GST**.

## Features
- Quick **cost estimator** (guards × wage × units) + **GST** at configurable rate (default 18%).
- Contact form with apartment details and guard requirement.
- Auto-calculated **Subtotal, GST amount, Total** embedded into the request.
- Local admin tools: table view + **Download CSV**.
- Optional **Netlify Forms** integration (server-side submissions).

## How to Use Locally
1. Open `index.html` in a browser.
2. Fill the estimator to get a quick total.
3. Submit the contact request.
4. Use **Admin → Download CSV** to export requests.

## Deploy Free
- **Netlify**: Drag-and-drop the folder, or connect your Git repo. The form includes `data-netlify="true"` and `form-name`.
- **GitHub Pages**: Push the folder to a repo and enable Pages.

## GST Notes (India)
- Security services generally attract **18% GST** under services classification (SAC), and many guides refer to RCM for non-body corporate suppliers since **Jan 2019**. Consult your tax advisor for specifics.  Sources: ClearTax, IndiaFilings. 
- Apartment **maintenance** collected by RWAs is typically **18% GST** when the monthly per-flat fee exceeds **₹7,500** and the society is GST-registered.  Sources: Economic Times, TaxRobo.

> This site defaults to **18% GST**. You can change the rate in the form to match your invoicing.

## Customize
- Branding: Change the header logo text in `index.html`.
- Default phone: update footer.
- Add more roles or fields by editing the **Guard Requirement** section.

## Privacy
Requests are saved in the visitor’s browser (**localStorage**) until exported. For production, add a backend, HTTPS, and a privacy policy.
