
(function(){
  const YEAR_EL = document.getElementById('year');
  YEAR_EL.textContent = new Date().getFullYear();

  // --- Estimator ---
  const estimatorForm = document.getElementById('estimatorForm');
  const estimateOutput = document.getElementById('estimateOutput');
  estimatorForm?.addEventListener('submit', (ev)=>{
    ev.preventDefault();
    const fd = new FormData(estimatorForm);
    const guards = +fd.get('guards');
    const wage = +fd.get('wage');
    const period = fd.get('wagePeriod');
    const units = +fd.get('units');
    const gstRate = +(fd.get('gst')||0);
    const subtotal = guards * wage * (period==='monthly'?1:units);
    const gstAmt = subtotal * (gstRate/100);
    const total = subtotal + gstAmt;
    estimateOutput.innerHTML = `<div class="summary">
      <strong>Subtotal:</strong> ₹${subtotal.toLocaleString('en-IN')}<br/>
      <strong>GST (${gstRate}%):</strong> ₹${gstAmt.toLocaleString('en-IN')}<br/>
      <strong>Total:</strong> ₹${total.toLocaleString('en-IN')}
    </div>`;
  });

  // --- Requests ---
  const requestForm = document.getElementById('requestForm');
  const requestSummary = document.getElementById('requestSummary');
  const requestStatus = document.getElementById('requestStatus');

  const STORAGE_KEY = 'aplus_guard_requests_v1';
  const readAll = () => JSON.parse(localStorage.getItem(STORAGE_KEY)||'[]');
  const writeAll = (rows) => localStorage.setItem(STORAGE_KEY, JSON.stringify(rows));

  function calcFromForm(fd){
    const guards = +fd.get('guards');
    const wage = +fd.get('wage');
    const period = fd.get('wagePeriod');
    const units = +fd.get('units');
    const gstRate = +fd.get('gst');
    const subtotal = guards * wage * (period==='monthly'?1:units);
    const gstAmt = subtotal * (gstRate/100);
    const gstIncluded = fd.get('gstIncluded')==='yes';
    const total = gstIncluded ? subtotal + gstAmt : subtotal;
    return {subtotal, gstAmt, total, gstRate, guards, wage, period, units};
  }

  function renderSummary(calc){
    requestSummary.innerHTML = `<div class="summary">
      <strong>Subtotal:</strong> ₹${calc.subtotal.toLocaleString('en-IN')}<br/>
      <strong>GST (${calc.gstRate}%):</strong> ₹${calc.gstAmt.toLocaleString('en-IN')}<br/>
      <strong>Total${calc.total===calc.subtotal? ' (GST excluded)' : ''}:</strong> ₹${calc.total.toLocaleString('en-IN')}
    </div>`;
  }

  function toRow(fd, calc){
    return {
      fullName: fd.get('fullName')||'',
      phone: fd.get('phone')||'',
      email: fd.get('email')||'',
      apartment: fd.get('apartment')||'',
      block: fd.get('block')||'',
      city: fd.get('city')||'',
      role: fd.get('role')||'',
      guards: fd.get('guards')||'',
      shift: fd.get('shift')||'',
      wage: fd.get('wage')||'',
      wagePeriod: fd.get('wagePeriod')||'',
      units: fd.get('units')||'',
      gst: fd.get('gst')||'',
      subtotal: calc.subtotal,
      gstAmt: calc.gstAmt,
      total: calc.total,
      notes: (fd.get('notes')||'').slice(0,200)
    };
  }

  function renderTable(){
    const tbody = document.querySelector('#requestsTable tbody');
    tbody.innerHTML = '';
    readAll().forEach(r => {
      const tr = document.createElement('tr');
      ['fullName','phone','email','apartment','city','role','guards','shift','wage','wagePeriod','units','gst','subtotal','gstAmt','total','notes']
      .forEach(k=>{
        const td = document.createElement('td');
        td.textContent = (k==='subtotal' || k==='gstAmt' || k==='total') ? `₹${Number(r[k]).toLocaleString('en-IN')}` : (r[k]||'');
        tr.appendChild(td);
      });
      tbody.appendChild(tr);
    });
  }

  requestForm?.addEventListener('input', ()=>{
    const fd = new FormData(requestForm);
    const calc = calcFromForm(fd);
    renderSummary(calc);
    requestForm.querySelector('[name="calcSubtotal"]').value = String(calc.subtotal);
    requestForm.querySelector('[name="calcGst"]').value = String(calc.gstAmt);
    requestForm.querySelector('[name="calcTotal"]').value = String(calc.total);
  });

  requestForm?.addEventListener('submit', (ev)=>{
    ev.preventDefault();
    const fd = new FormData(requestForm);
    const calc = calcFromForm(fd);
    renderSummary(calc);
    const row = toRow(fd, calc);
    const rows = readAll();
    rows.push(row);
    writeAll(rows);
    renderTable();
    requestStatus.textContent = 'Request saved locally. If deployed on Netlify, it will also be submitted to your dashboard.';
    requestForm.reset();
    requestSummary.innerHTML = '';
  });

  // Admin actions
  const exportBtn = document.getElementById('exportCsv');
  const clearBtn = document.getElementById('clearAll');

  function toCSV(rows){
    const headers = ['Name','Phone','Email','Apartment','City','Role','Guards','Shift','Wage','Period','Units','GST%','Subtotal','GST Amt','Total','Notes'];
    const keyMap = ['fullName','phone','email','apartment','city','role','guards','shift','wage','wagePeriod','units','gst','subtotal','gstAmt','total','notes'];
    const lines = [headers.join(',')].concat(rows.map(r => headers.map((h,i)=>{
      const v = r[keyMap[i]] ?? '';
      const s = String(v).replace(/"/g,'""');
      return /,|
||"/.test(s) ? '"'+s+'"' : s;
    }).join(',')));
    return lines.join('
');
  }

  exportBtn?.addEventListener('click', ()=>{
    const csv = toCSV(readAll());
    const blob = new Blob([csv], {type:'text/csv'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'guard-requests.csv';
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  });

  clearBtn?.addEventListener('click', ()=>{
    if(confirm('Delete ALL locally stored requests?')){
      localStorage.removeItem(STORAGE_KEY);
      renderTable();
    }
  });

  renderTable();
})();
